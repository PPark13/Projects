package gardnerg.uw.tacoma.edu.tomogotchi;

import org.junit.Test;

import static junit.framework.Assert.assertNotNull;
import static junit.framework.Assert.fail;

/**
 * Created by VG Gnome on 5/11/2017.
 */

public class AccountTest {
    @Test
    public void testAccountConstructor() {
        assertNotNull(new Account("mmuppa@uw.edu", "test1@3"));
    }
    @Test
    public void testAccountConstructorBadEmail() {
        try {
            new Account("mmuppauw.edu", "test1@3");
            fail("Account created with invalid email");
        } catch(IllegalArgumentException e) {

        }
    }

}
