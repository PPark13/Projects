/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package listeners;

import gui.Canvas;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JColorChooser;
/**
 * This class lets the user choose a new color.
 * 
 * @author Peter Park
 * @version 1
 */
public class ColorAction extends AbstractAction {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 5932559100278488795L;

    /**
     * The size of the icon.
     */
    private static final int ICON_SIZE = 20;
    
    /**
     * The red value for the color UW purple.
     */
    private static final int UW_RED = 51;
    
    /**
     * The blue value for the color UW purple.
     */
    private static final int UW_BLUE = 111;

    /**
     * The Canvas to change tool colors with.
     */
    private final Canvas myCanvas;
    
    /**
     * The constructor for ColorAction class. Also adds the ColorIcon class as an image.
     * 
     * @param theCanvas the drawing panel to draw the icon.
     */
    public ColorAction(final Canvas theCanvas) {
        super("Color...", new ColorIcon(ICON_SIZE, new Color(UW_RED, 0, UW_BLUE)));
        putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);
        myCanvas = theCanvas;
    }

    /**
     * Sets the color for the canvas.
     * 
     * @param theEvent the event that prompts the color chooser.
     */
    public void actionPerformed(final ActionEvent theEvent) {
        final Color colorChosen = JColorChooser.showDialog(myCanvas, "Select a new color", 
                                                           null);
        if (colorChosen != null) {
            putValue(Action.SMALL_ICON, new ColorIcon(ICON_SIZE, colorChosen));
            myCanvas.setColor(colorChosen);
        }
    }
}
