/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.Shape;
import java.awt.geom.Line2D;

/**
/**
 * This class creates a line tool.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class Line extends AbstractTool {
    /**
     * The line object to draw with.
     */
    private Line2D myLine;

    /**
     * Constructor for the Line class.
     */
    public Line() {
        super();
        myLine = new Line2D.Double();
    }

    /**
     * Starts to draw the line at the initial x and y coordinates.
     *
     * @return myLine the start of the line.
     */
    public Shape start() {
        myLine = new Line2D.Double(myInitialX, myInitialY, myInitialX, myInitialY);
        return  myLine;
    }

    /**
     * Sets the line from the initial x and y coordinates to the new ones passed.
     * 
     * @return myLine the moved line.
     */
    public Shape move() {
        myLine.setLine(myInitialX, myInitialY, myEndX, myEndY);
        return myLine;
    }
}
