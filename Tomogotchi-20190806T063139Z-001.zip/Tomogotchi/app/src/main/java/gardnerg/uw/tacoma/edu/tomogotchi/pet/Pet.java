package gardnerg.uw.tacoma.edu.tomogotchi.pet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.List;

import gardnerg.uw.tacoma.edu.tomogotchi.Account;

/**
 * Created by VG Gnome on 5/11/2017.
 */

public class Pet implements Serializable {

    public int THREE = 3;
    public static final String TYPE = "kind",HUNGER = "hunger",HYGENE = "hygene",ENERGY = "energy"
            ,HAPPINESS="happiness",STAGE="stage",NAME="petname", ID="id";
    private int Id,petType,petHunger,petHygene,petEnergy,petHappiness,petStage;
    private String petName;


    public Pet(String theName, int theType,Account account) {
        setPetEnergy(THREE);
        setPetHappiness(THREE);
        setPetHunger(THREE);
        setPetHygene(THREE);
        setPetStage(0);
        setPetType(theType);
        setPetName(theName);
        setId(account.myId);
    }
    public Pet(int Id,int petType,int petHunger, int petHygene, int petEnergy,
                    int petHappiness,int petStage, String petName) {
        setPetEnergy(petEnergy);
        setPetHappiness(petHappiness);
        setPetHunger(petHunger);
        setPetHygene(petHygene);
        setPetStage(petStage);
        setPetType(petType);
        setPetName(petName);
        setId(Id);
    }

    public int getPetType() {
        return petType;
    }

    public void setPetType(int petType) {
        this.petType = petType;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public int getPetHunger() {
        return petHunger;
    }

    public void setPetHunger(int petHunger) {
        this.petHunger = petHunger;
    }

    public int getPetHygene() {
        return petHygene;
    }

    public void setPetHygene(int petHygene) {
        this.petHygene = petHygene;
    }

    public int getPetEnergy() {
        return petEnergy;
    }

    public void setPetEnergy(int petEnergy) {
        this.petEnergy = petEnergy;
    }

    public int getPetHappiness() {
        return petHappiness;
    }

    public void setPetHappiness(int petHappiness) {
        this.petHappiness = petHappiness;
    }

    public int getPetStage() {
        return petStage;
    }

    public void setPetStage(int petStage) {
        this.petStage = petStage;
    }

    public int getId() {
        return Id;
    }
    private void setId(int i) {
        Id = i;
    }

    public static String parsePetJSON(String courseJSON, List<Pet> petList) {
        String reason = null;
        if (courseJSON != null) {
            try {
                JSONArray arr = new JSONArray(courseJSON);

                for (int i = 0; i < arr.length(); i++) {
                    JSONObject obj = arr.getJSONObject(i);

                    Pet tomogotchi = new Pet(obj.getInt(ID),obj.getInt(TYPE),obj.getInt(HUNGER),obj.getInt(HYGENE),obj.getInt(ENERGY)
                            ,obj.getInt(HAPPINESS),obj.getInt(STAGE),obj.getString(NAME));
                    petList.add(tomogotchi);


                }
//                for(int i = 0; i<arr.length();i++){
//                    System.out.println(courseList.get(i).getMcourseid() + " this is a test");
//                }
            } catch (JSONException e) {
                reason =  "Unable to parse data, Reason: " + e.getMessage();
            }

        }
        return reason;
    }
}
