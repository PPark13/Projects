/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package listeners;

import gui.Canvas;

import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;

import tools.ToolInterface;

/**
 * This class determines the actions for every tool.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class ToolAction extends AbstractAction {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 8144195291819395374L;

    /**
     * The default tool which is the pencil tool.
     */
    private static final String DEFAULT_TOOL = "Pencil";

    /**
     * The canvas to attach listeners to.
     */
    private final Canvas myCanvas;

    /**
     * The current tool.
     */
    private final ToolInterface myTool;

    /**
     *  The current shape being drawn. 
     */
    private Shape myCurrentShape;

    /**
     * The check to see if the square/circle button is toggled on.
     */
    private boolean mySquareCircle;

    /**
     * The constructor for the ToolAction class. This sets up the fields and listeners.
     * 
     * @param theCanvas the canvas being used to draw.
     * @param theTool the tool being used.
     */
    public ToolAction(final Canvas theCanvas, final ToolInterface theTool) {
        super(theTool.getName());
        putValue(Action.MNEMONIC_KEY,
                 KeyEvent.getExtendedKeyCodeForChar(theTool.getName().codePointAt(0)));
        
        myCanvas = theCanvas;
        myTool = theTool;
        mySquareCircle = false;

        final ToolListener listener = new ToolListener();
        myCanvas.addMouseListener(listener);
        myCanvas.addMouseMotionListener(listener);
        if (theTool.getName().equals(DEFAULT_TOOL)) {
            putValue(Action.SELECTED_KEY, true);
            myCanvas.setTool(theTool);
        }
    }

    /**
     * Returns the name of the tool.
     * 
     * @return String the tool's name.
     */
    public String getName() {
        return myTool.getName();
    }

    /**
     * Checks to see if the square/circle button is toggled on. Sets to true if it is.
     * 
     * @param theSquareCircle true if the square/circle menu item is toggled on.
     */
    public void setSquareCircle(final boolean theSquareCircle) {
        mySquareCircle = theSquareCircle;
    }

    /**
     * Toggles the tool to be selected if the user toggles it on.
     * 
     * @param theEvent the event that toggles the button.
     */
    public void actionPerformed(final ActionEvent theEvent) {
        putValue(Action.SELECTED_KEY, true);
        myCanvas.setTool(myTool);
    }

    /**
     * Inner class that extends mouse adapter to handle mouse events.
     * 
     * @author Peter Park
     * @version 8.1
     */
    private class ToolListener extends MouseAdapter {
        /**
         * If the mouse is pressed, this method checks to see if the square/circle button is
         * toggled on. Then, it sets the start point, begins drawing.
         * 
         * @param theEvent the mouse pressed event.
         */
        public void mousePressed(final MouseEvent theEvent) {
            if (myTool.getName().equals(myCanvas.getTool().getName())) {
                if (mySquareCircle) {
                    myTool.setSquareCircle(true);                   
                } else {
                    myTool.setSquareCircle(false); 
                }
                myTool.setStartPoint(theEvent.getX(), theEvent.getY());
                myCurrentShape = myTool.start();
                myCanvas.setCurrentDrawing(myCurrentShape);
                myCanvas.repaint();
            }
        }

        /**
         * If the mouse is dragged, this method checks sets the end point for the drawing,
         * draws, as repaints the canvas.
         * 
         * @param theEvent the mouse dragged event. 
         */
        public void mouseDragged(final MouseEvent theEvent) {
            if (myTool.getName().equals(myCanvas.getTool().getName())) {
                myTool.setEndPoint(theEvent.getX(), theEvent.getY());
                myCurrentShape = myTool.move();
                myCanvas.repaint();
            }
        }

        /**
         * When the mouse is released it triggers the stop event for the tool.
         * @param theEvent the mouse event
         */
        public void mouseReleased(final MouseEvent theEvent) {
            if (myCanvas.getThickness() != 0 
                            && myTool.getName().equals(myCanvas.getTool().getName())) {
                myCanvas.addDrawing(myCurrentShape);
                myCanvas.repaint();
            }
        }
    }
}
