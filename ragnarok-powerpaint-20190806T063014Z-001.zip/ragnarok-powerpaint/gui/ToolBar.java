/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package gui;

import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;

import listeners.ToolAction;

/**
 * 
 * @author Peter Park
 * @version 8.1
 */
public class ToolBar extends JToolBar {
    
    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 7035628944311030873L;
    
    /**
     * The collection of tools.
     */
    private final List<ToolAction> myToolActions;
        
    /**
     * The constructor for the tool bar.
     * 
     * @param theToolActions .
     */
    public ToolBar(final List<ToolAction> theToolActions) {
        super();
        myToolActions = theToolActions;
        setup();
    }
    
    /**
     * Creates the toggle buttons and sets the icons for each tool.
     */
    private void setup() {
        JToggleButton toggleButton;
        final ButtonGroup toolbarGroup = new ButtonGroup();
        for (final ToolAction tool : myToolActions) {
            toggleButton = new JToggleButton(tool);
            toggleButton.setIcon(new ImageIcon("images/" 
                            + tool.getName().toLowerCase() + "_bw.gif"));
            add(toggleButton);
            toolbarGroup.add(toggleButton);
        }
    }
}
