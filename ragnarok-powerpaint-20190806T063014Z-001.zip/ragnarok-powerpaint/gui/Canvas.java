/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package gui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import tools.Drawing;
import tools.ToolInterface;

/**
 * This class draws, saves, and clears drawings. It also sets the color, thickness, 
 * and tool used.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class Canvas extends JPanel {
        
    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 3165411042103419045L;
        
    /**
     * The default thickness for the drawing.
     */
    private static final int DEFAULT_THICKNESS = 5;
    
    /**
     * The height of the panel.
     */
    private static final int HEIGHT = 400;

    /**
     * The width of the panel.
     */
    private static final int WIDTH = 500;
    
    /**
     * The red value for the color UW purple.
     */
    private static final int UW_RED = 51;
    
    /**
     * The blue value for the color UW purple.
     */
    private static final int UW_BLUE = 111;
    
    /**
     * The name of the property that is being fired.
     */
    private static final String HAS_DRAWING = "ART";
    
    /**
     * A collection of all the drawings.
     */
    private final List<Drawing> myFinishedDrawings;

    /**
     * The tool currently in use on the drawing panel.
     */
    private ToolInterface myTool;
    
    /**
     * The color of the tool.
     */
    private Color myColor;

    /**
     * The thickness of the tool in use.
     */
    private int myThickness;

    /**
     * The current drawing being drawn.
     */
    private Shape myCurrentDrawing;

    /**
     * A check to see if something is being drawn.
     */
    private boolean myHasCurrentDrawing;
    
    /**
     * A constructor that sets the fields and default settings such as width, height, 
     * background color, and the cursor.
     */
    public Canvas() {
        super();
        myColor = new Color(UW_RED, 0, UW_BLUE);
        myThickness = DEFAULT_THICKNESS;
        myFinishedDrawings = new ArrayList<Drawing>();
        myHasCurrentDrawing = false;
        
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
        setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
    }

    /**
     * Adds the finished shape to the collection of drawings.
     * 
     * @param theShape the shape of the finished drawing.
     */
    public void addDrawing(final Shape theShape) {
        myFinishedDrawings.add(new Drawing(theShape, myColor, myThickness));
        myHasCurrentDrawing = false;
        firePropertyChange(HAS_DRAWING, myFinishedDrawings.isEmpty(), 
                           !myFinishedDrawings.isEmpty());
    }

    /**
     * Sets which shape is being drawn currently.
     * 
     * @param theShape the shape of the current drawing.
     */
    public void setCurrentDrawing(final Shape theShape) {
        myCurrentDrawing = theShape;
        myHasCurrentDrawing = true;
    }

    /**
     * Removes all of the drawings from the collection and on the panel.
     */
    public void clearDrawings() {
        myFinishedDrawings.clear();
        myHasCurrentDrawing = false;
        repaint();
    }

    /**
     * Returns what tool is in use.
     * 
     * @return the current tool in use.
     */
    public final ToolInterface getTool() {
        return myTool;
    }

    /**
     * Sets which tool is in use.
     * 
     * @param theTool the tool to be used.
     */
    public void setTool(final ToolInterface theTool) {
        myTool = theTool;
    }

    /**
     * Set the color of the drawing.
     * 
     * @param theColor the color to set the drawing.
     */
    public void setColor(final Color theColor) {
        myColor = theColor;
    }

    /**
     * Gets the color being used to draw.
     * 
     * @return the color being used.
     */
    public final Color getColor() {
        return myColor;
    }

    /**
     * Gets the thickness being used to draw.
     * 
     * @return the thickness being used.
     */
    public int getThickness() {
        return myThickness;
    }

    /**
     * Set the thickness for the drawing.
     * 
     * @param theThickness the thickness to be used.
     */
    public void setThickness(final int theThickness) {
        myThickness = theThickness;
    }

    /**
     * Paints all of the drawings that were stored and adds to the collection.
     * 
     * @param theGraphics The graphics to use to draw.
     */
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics;
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                             RenderingHints.VALUE_ANTIALIAS_ON); 

        for (final Drawing art : myFinishedDrawings) {
            g2d.setColor(art.getColor());
            g2d.setStroke(art.getThickness());
            g2d.draw(art.getShape());
        }
        
        if (myThickness != 0 && myHasCurrentDrawing) {
            g2d.setColor(myColor);
            g2d.setStroke(new BasicStroke(myThickness));
            g2d.draw(myCurrentDrawing);
        }
    }
}
