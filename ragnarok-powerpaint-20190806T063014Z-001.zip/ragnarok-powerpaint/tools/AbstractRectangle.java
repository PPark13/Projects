/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.Shape;
import java.awt.geom.RectangularShape;

/**
 * This class to draws shapes which use a rectangular frame (rectangle and ellipse).
 * 
 * @author Peter Park
 * @version 8.1
 */
public abstract class AbstractRectangle extends AbstractTool {

    /**
     * The rectangular shape being drawn.
     */
    private RectangularShape myShape;

    /**
     * The constructor for the AbstractRectangle class. This sets the shape.
     * 
     * @param theShape the shape to set the class.
     */
    public AbstractRectangle(final RectangularShape theShape) {
        super();
        myShape = theShape;
    }

    /**
     * Starts the rectangular shape at the initial x and y coordinates.
     *
     * @return myShape the rectangular shape.
     */
    public Shape start() {
        myShape = (RectangularShape) myShape.clone();
        myShape.setFrameFromDiagonal(myInitialX, myInitialY, myInitialX, myInitialY);
        return myShape;
    }

    /**
     * Sets the rectangle from the initial x and y coordinates to the new ones passed.
     * in from the mouse pointer.
     * 
     * @return myShape the new rectangular shape.
     */
    public Shape move() {
        if (mySquareCircle) {
            myShape = (RectangularShape) squareCircleMove();
        } else {
            myShape.setFrameFromDiagonal(myInitialX, myInitialY, myEndX, myEndY);
        }
        return myShape;
    }
    
    /**
     * Sets the rectangular shape to have a square frame if the square/circle button is
     * toggled on.
     * 
     * @return myShape the new rectangular shape with a square bounding box.
     */
    public Shape squareCircleMove() {
        int temp;
        final int differenceX = myEndX - myInitialX;        
        final int differenceY = myEndY - myInitialY;
        
        final boolean xIsBigger = Math.abs(myInitialX - myEndX) 
                        > Math.abs(myInitialY - myEndY);

        if (myEndX > myInitialX && myEndY < myInitialY) {
            if (xIsBigger) {
                temp = -differenceY;
                myShape.setFrameFromDiagonal(myInitialX, 
                                             myInitialY, temp + myInitialX, myEndY);
            } else {
                temp = -differenceX;
                myShape.setFrameFromDiagonal(myInitialX, 
                                             myInitialY, myEndX, temp + myInitialY);
            }
        } else if (myEndX < myInitialX && myEndY > myInitialY) { 
            if (xIsBigger) {
                temp = differenceY;
                myShape.setFrameFromDiagonal(myInitialX, 
                                             myInitialY, myInitialX - temp, myEndY);
            } else {
                temp = differenceX;
                myShape.setFrameFromDiagonal(myInitialX, 
                                             myInitialY, myEndX, myInitialY - temp);
            }
        } else {
            if (xIsBigger) {
                temp = differenceY;
            } else {
                temp = differenceX;
            }
            myShape.setFrameFromDiagonal(myInitialX, myInitialY, 
                                         temp + myInitialX, temp + myInitialY);
        }
        return myShape;
    }
}
