# A.I._Pentago
An implementation of the game Pentago, using an AI opponent, and coded in Python.
