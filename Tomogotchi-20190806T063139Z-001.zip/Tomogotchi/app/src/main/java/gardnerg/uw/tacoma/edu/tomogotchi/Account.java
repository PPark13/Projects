package gardnerg.uw.tacoma.edu.tomogotchi;

import java.util.Random;
import java.util.regex.Pattern;

/**
 * Created by VG Gnome on 5/11/2017.
 */

public class Account {
    /**
     * Email validation pattern.
     */
    public static final Pattern EMAIL_PATTERN = Pattern.compile(
            "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}" +
                    "\\@" +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}" +
                    "(" +
                    "\\." +
                    "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" +
                    ")+"
    );
    private String myEmail;
    private String myPass;
    public final int myId;
    public static int hasPet;
    private final static int PASSWORD_LEN = 6;

    public Account(String theEmail, String thePass){
        if(isValidEmail(theEmail) && isValidPassword(thePass)) {
            setMyEmail(theEmail);
            setMyPass(thePass);
            Random r = new Random();
            myId = r.nextInt();
            hasPet = 0;
        } else {
            throw new IllegalArgumentException("Incorect Data for Email or Password.");
        }
    }


    /**
     * Validates if the given input is a valid email address.
     *
     * @param email        The email to validate.
     * @return {@code true} if the input is a valid email. {@code false} otherwise.
     */
    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    /**
     * Validates if the given password is valid.
     * Valid password must be at last 6 characters long
     * with at least one digit and one symbol.
     *
     * @param password        The password to validate.
     * @return {@code true} if the input is a valid password.
     * {@code false} otherwise.
     */
    public static boolean isValidPassword(String password) {
        boolean foundDigit = false, foundSymbol = false;
        if  (password == null ||
                password.length() < PASSWORD_LEN)
            return false;
        for (int i=0; i<password.length(); i++) {
            if (Character.isDigit(password.charAt(i)))
                foundDigit = true;
            if (!Character.isLetterOrDigit(password.charAt(i)))
                foundSymbol = true;
        }
        return foundDigit && foundSymbol;
    }



    public String getMyEmail() {
        return myEmail;
    }

    public void setMyEmail(String theEmail) {
        this.myEmail = theEmail;
    }

    public String getMyPass() {
        return myPass;
    }

    public void setMyPass(String thePass) {
        this.myPass = thePass;
    }
    public void setHasPet(int b) {
        hasPet = b;
    }
    public int getHasPet(){ return hasPet; }
    public int getMyId() {
        return myId;
    }

}
