/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

import view.TetrisGUI;

/**
 * This class starts a game of Tetris.
 * 
 * @author Peter Park
 * @version 4.0
 *
 */
public final class TetrisMain {
    
    /**
     * The default constructor for this class.
     */
    private TetrisMain() {
        super();
    }
    
    /**
     * This method starts the game.
     * 
     * @param theArgs Comment line argument (ignored).
     */
    public static void main(final String... theArgs) {
        new TetrisGUI().start();
    }
}
