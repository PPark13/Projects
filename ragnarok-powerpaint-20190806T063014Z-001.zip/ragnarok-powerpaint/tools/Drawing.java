/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Shape;
import java.awt.Stroke;

/**
 * This class contains the characteristics of a finished drawing.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class Drawing {
    /**
     * The shape of the drawing.
     */
    private final Shape myShape;

    /**
     * The color of the drawing.
     */
    private final Color myColor;

    /**
     * The thickness of the drawing.
     */
    private final Stroke myThickness;

    /**
     * Constructor for the Drawing class. Sets the shape, color, and thickness.
     * 
     * @param theShape the shape of the drawing.
     * @param theColor the color of the drawing.
     * @param theThickness the thickness of the drawing.
     */
    public Drawing(final Shape theShape, final Color theColor, final int theThickness) {
        myShape = theShape;
        myColor = theColor;
        myThickness = new BasicStroke(theThickness); 
    }

    /**
     * Returns the shape of the drawing.
     * 
     * @return myShape the shape of the drawing.
     */
    public Shape getShape() {
        return myShape;
    }

    /**
     * Returns the color of the drawing.
     * @return myColor the color of the drawing.
     */
    public Color getColor() {
        return myColor;
    }

    /**
     * Returns the thickness of the drawing.
     * 
     * @return myThickness the thickness of the drawing.
     */
    public Stroke getThickness() {
        return myThickness;
    }
}
