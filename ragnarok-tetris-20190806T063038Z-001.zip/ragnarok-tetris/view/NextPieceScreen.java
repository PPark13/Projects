/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Rectangle2D;

import javax.swing.JPanel;

import model.Block;
import model.Point;
import model.TetrisPiece;

/**
 * This class displays the next piece that will be put into play.
 * 
 * @author Peter Park
 * @version 4.0
 */
public class NextPieceScreen extends JPanel {
    
    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = -2394013683325414976L;

    /**
     * The scale by which the size of the board and pieces are increased by.
     */
    private static final int SCALE = 30;
    
    /**
     * The helper integer that is used for spacing purposes.
     */
    private static final int SPACING = 20;

    /**
     * The width of the panel.
     */
    private static final int WIDTH = 200;

    /**
     * The height of the panel.
     */
    private static final int HEIGHT = 200;
    
    /**
     * The default stroke thickness.
     */
    private static final int DEFAULT_STROKE = 2; 
    
    /**
     * The points of the next Tetris piece.
     */
    private static Point[] myPoints;

    /**
     * Piece that is next to play.
     */
    private static TetrisPiece myNextPiece;

    /**
     * The shape of the blocks that will be drawn.
     */
    private final Rectangle2D myPieceShape;

    /**
     * The stroke thickness to draw the Tetris blocks.
     */
    private final Stroke myStroke;
    
    /**
     * Determines whether to draw in color or in black and white.
     */
    private boolean myColor;

    /**
     * The default constructor for this class.
     */
    public NextPieceScreen() {
        super();
        
        myPieceShape = new Rectangle2D.Double();
        myStroke = new BasicStroke(DEFAULT_STROKE);
        myColor = false;
        
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
    }

    /**
     * This class sets the next piece that will be shown.
     * 
     * @param thePiece the current piece to draw.
     */
    public static void setPiece(final TetrisPiece thePiece) {
        myNextPiece = thePiece;
        myPoints = myNextPiece.getPoints();
    }
    
    /**
     * Toggles the boolean for whether to draw in color.
     */
    public void toggleColors() {
        myColor ^= true;
    }

    /**
     * This class paints the next piece that will be used.
     * 
     * @param theGraphics the graphics object.
     */
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics;

        g2d.setStroke(myStroke);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                             RenderingHints.VALUE_ANTIALIAS_ON); 
        
        g2d.setColor(Color.GRAY);
        g2d.fill(new Rectangle(WIDTH / SPACING, WIDTH / SPACING, 
                               WIDTH - SPACING, HEIGHT - SPACING));

        for (final Point point : myPoints) {
            myPieceShape.setFrame(point.x() * SCALE 
                                  + (SPACING * 2), point.y() * SCALE * -1 
                                  + (HEIGHT / 2 + SPACING), SCALE, SCALE);
            if (myColor) {
                if (myNextPiece.getBlock() == Block.I) {
                    g2d.setColor(Color.CYAN);
                } else if (myNextPiece.getBlock() == Block.J) {
                    g2d.setColor(Color.BLUE);
                } else if (myNextPiece.getBlock() == Block.L) {
                    g2d.setColor(Color.ORANGE);
                } else if (myNextPiece.getBlock() == Block.O) {
                    g2d.setColor(Color.YELLOW);
                } else if (myNextPiece.getBlock() == Block.S) {
                    g2d.setColor(Color.GREEN);
                } else if (myNextPiece.getBlock() == Block.T) {
                    g2d.setColor(Color.MAGENTA);
                } else if (myNextPiece.getBlock() == Block.Z) {
                    g2d.setColor(Color.RED);
                }
            } else {
                g2d.setColor(Color.WHITE);
            }
            g2d.fill(myPieceShape);
            g2d.setColor(Color.BLACK);
            g2d.draw(myPieceShape);
        }
    }
}
