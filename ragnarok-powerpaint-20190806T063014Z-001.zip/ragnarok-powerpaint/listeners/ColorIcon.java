/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package listeners;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.Icon;


/**
 * A class to make colored rectangles to use as icons.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class ColorIcon implements Icon {
    
    /**
     * The size of the Icon (width and height).
     */
    private final int mySize;
    
    /**
     * The color to set the icon.
     */
    private final Color myColor;
    
    /**
     * The constructor for the ColorIcon class.
     * 
     * @param theSize the size to set the icon.
     * @param theColor the color to set the icon
     */
    public ColorIcon(final int theSize, final Color theColor) {
        mySize = theSize;
        myColor = theColor;
    }

    /**
     * Paints the icon onto the drawing panel which shows the color that is being used.
     * 
     * @param theC the component (ignored).
     * @param theG the graphics object being used to draw with.
     * @param theX the x coordinate for the icon.
     * @param theY the y coordinate for the icon.
     */
    public void paintIcon(final Component theC, final Graphics theG, 
                          final int theX, final int theY) {
        final Graphics2D g2d = (Graphics2D) theG.create();

        g2d.setColor(myColor);
        g2d.fillRect(theX + 1 , theY + 1, mySize - 2 , mySize - 2);

        g2d.setColor(Color.BLACK);
        g2d.drawRect(theX + 1 , theY + 1, mySize - 2 , mySize - 2);
        g2d.dispose();
    }

    /**
     * Returns the width of the icon.
     * 
     * @return mySize the width of the icon.
     */
    public int getIconWidth() {
        return mySize;
    }

    /**
     * Returns the height of the icon.
     * 
     * @return mySize the height of the icon.
     */
    public int getIconHeight() {
        return mySize;
    }
}
