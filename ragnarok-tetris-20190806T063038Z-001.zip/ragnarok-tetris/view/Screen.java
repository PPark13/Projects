/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import model.Block;

/**
 * This class draws the Tetris pieces on the screen.
 * 
 * @author Peter Park
 * @version 4.0
 */
public class Screen extends JPanel {
            
    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = -4520466899625211325L;

    /**
     * The scale by which the size of the board and pieces are increased by.
     */
    private static final int SCALE = 30;
    
    /**
     * Default width of a Tetris game board.
     */
    private static final int BOARD_WIDTH = 10;

    /**
     * Default height of a Tetris game board.
     */
    private static final int BOARD_HEIGHT = 20;
    
    /**
     * The width of the panel.
     */
    private static final int WIDTH = BOARD_WIDTH * SCALE;

    /**
     * The height of the panel.
     */
    private static final int HEIGHT = BOARD_HEIGHT * SCALE;
    
    /**
     * The default stroke thickness.
     */
    private static final int DEFAULT_STROKE = 2; 
    
    /**
     * The positions of the blocks on the board.
     */
    private List<Block[]> myBlocks;
    
    /**
     * The shape of the Tetris piece.
     */
    private final Rectangle2D myPieceShape;
    
    /**
     * The stroke thickness for the pieces.
     */
    private final Stroke myStroke;
    
    /**
     * The color to draw the Tetris pieces.
     */
    private boolean myColor;
    
    /**
     * The check to see whether to draw a grid on the board.
     */
    private boolean myGrid;
    
    /**
     * The default constructor for this class.
     */
    public Screen() {
        super();
        
        myPieceShape = new Rectangle2D.Double();
        myBlocks = new ArrayList<Block[]>();
        myStroke = new BasicStroke(DEFAULT_STROKE);
        myColor = false;
        myGrid = false;
        
        setBackground(Color.LIGHT_GRAY);
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
    }
    
    /**
     * This class updates the block positions.
     * 
     * @param theBlocks the current block positions.
     */
    public void updateBlocks(final List<Block[]> theBlocks) {
        myBlocks = theBlocks;
    }
    
    /**
     * This method toggles whether to draw in color.
     */
    public void toggleColors() {
        myColor ^= true;
    }
    
    /**
     * This method toggles whether to draw a grid.
     */
    public void toggleGrid() {
        myGrid ^= true;
    }
    
    /**
     * This class determines the color of the blocks.
     * 
     * @param theBlock the block to draw.
     * @return Color the color to set.
     */
    private Color colorBlocks(final Block theBlock) {
        Color temp;
        if (theBlock == Block.I) {
            temp = Color.CYAN;
        } else if (theBlock == Block.J) {
            temp = Color.BLUE;
        } else if (theBlock == Block.L) {
            temp = Color.ORANGE;
        } else if (theBlock == Block.O) {
            temp = Color.YELLOW;
        } else if (theBlock == Block.S) {
            temp = Color.GREEN;
        } else if (theBlock == Block.T) {
            temp = Color.MAGENTA;
        } else if (theBlock == Block.Z) {
            temp = Color.RED;
        } else {
            temp = Color.WHITE;
        }
        return temp;
    }

    /**
     * This class paints the screen with the Tetris pieces on the board.
     * 
     * @param theGraphics the graphics object.
     */
    public void paintComponent(final Graphics theGraphics) {
        super.paintComponent(theGraphics);
        final Graphics2D g2d = (Graphics2D) theGraphics;

        g2d.setStroke(myStroke);
        
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
                             RenderingHints.VALUE_ANTIALIAS_ON);
                                
        for (int i = 0; i < myBlocks.size(); i++) {
            for (int j = 0; j < myBlocks.get(i).length; j++) {
                myPieceShape.setFrame(j * SCALE,
                                      -1 * i * SCALE + HEIGHT - SCALE - 1, SCALE, SCALE);
                if (myBlocks.get(i)[j] != null) {
                    if (myColor) {
                        g2d.setColor(colorBlocks(myBlocks.get(i)[j]));
                    } else {
                        g2d.setColor(Color.WHITE);
                    }
                    g2d.fill(myPieceShape);
                    g2d.setColor(Color.BLACK);
                    g2d.draw(myPieceShape);
                }
            }          
        }
        
        if (myGrid) {
            for (int i = 0; i < WIDTH / BOARD_WIDTH; i++) {
                g2d.draw(new Line2D.Double(i * SCALE, 0, i * SCALE, HEIGHT));
                g2d.draw(new Line2D.Double(0, i * SCALE, WIDTH, i * SCALE));
    
            }
        }
    }
}
