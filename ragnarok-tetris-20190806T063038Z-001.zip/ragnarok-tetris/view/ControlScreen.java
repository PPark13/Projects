/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

package view;

import java.awt.event.KeyEvent;

import javax.swing.JTextPane;

/**
 * This class displays the controls for the game.
 * 
 * @author Peter Park
 * @version 4.0
 */
public class ControlScreen extends JTextPane {
        
    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = -1722279594787265260L;
    
    /**
     * This string contains all of the control information.
     */
    private String myControls;
    
    /**
     * The key that moves the Tetris piece left.
     */
    private int myLeftKey;
    
    /**
     * The key that moves the Tetris piece right.
     */
    private int myRightKey;

    /**
     * The key that moves the Tetris piece down.
     */
    private int myDownKey;

    /**
     * The key that drops the Tetris piece to the bottom of the board.
     */
    private int myDropKey;

    /**
     * The key that rotates the Tetris piece clockwise.
     */
    private int myCWKey;

    /**
     * The key that rotates the Tetris piece counter-clockwise.
     */
    private int myCCWKey;
    
    /**
     * This is the default constructor for this class.
     */
    public ControlScreen() {
        super();
        
        setFocusable(false);
        setupKeys();
        setupText();
        setText(myControls);
    }
    
    /**
     * Sets up the default key settings to write.
     */
    private void setupKeys() {
        myLeftKey = KeyEvent.VK_LEFT;
        myRightKey = KeyEvent.VK_RIGHT;
        myDownKey = KeyEvent.VK_DOWN;
        myDropKey = KeyEvent.VK_SPACE;
        myCWKey = KeyEvent.VK_X;
        myCCWKey = KeyEvent.VK_Z;
    }
    
    /**
     * This class sets the new keys that the user inputs.
     * 
     * @param theLeft the key that moves the Tetris piece left.
     * @param theRight the key that moves the Tetris piece right.
     * @param theDown the key that moves the Tetris piece down.
     * @param theDrop the key that drops the Tetris piece to the bottom.
     * @param theCW the key that rotates the Tetris piece clockwise.
     * @param theCCW the key that rotates the Tetris piece clockwise.
     */
    public void setKeys(final int theLeft, final int theRight, final int theDown, 
                        final int theDrop, final int theCW, final int theCCW) {
        myLeftKey = theLeft;
        myRightKey = theRight;
        myDownKey = theDown;
        myDropKey = theDrop;
        myCWKey = theCW;
        myCCWKey = theCCW;
        setupText();
        setText(myControls);
    }
    
    /**
     * This method writes the text that displays the controls.
     */
    private void setupText() {      
        myControls = "";
        myControls += "                   Controls\n";
        myControls += "\n Move Left = " + KeyEvent.getKeyText(myLeftKey);
        myControls += "\n Move Right = " + KeyEvent.getKeyText(myRightKey);
        myControls += "\n Move Down = " + KeyEvent.getKeyText(myDownKey);
        myControls += "\n Drop Down = " + KeyEvent.getKeyText(myDropKey);
        myControls += "\n Rotate CW = " + KeyEvent.getKeyText(myCWKey);
        myControls += "\n Rotate CCW = " + KeyEvent.getKeyText(myCCWKey);
        myControls += "\n Pause = P";
    }
}
