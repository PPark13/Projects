/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

/**
 * 
 * @author Peter Park
 * @version 4.0
 */
public class TetrisMenuBar extends JMenuBar {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 8910453698152212853L;

    /**
     * The GUI for Tetris.
     */
    private final TetrisGUI myTetrisGUI;

    /**
     * The screen that displays the controls.
     */
    private final ControlScreen myControlScreen;

    /**
     * The screen that displays the Tetris pieces.
     */
    private final Screen myScreen;

    /**
     * The screen that displays the next Tetris piece.
     */
    private final NextPieceScreen myPieceScreen;

    /**
     * The key that moves the Tetris piece left.
     */
    private int myLeftKey;

    /**
     * The key that moves the Tetris piece right.
     */
    private int myRightKey;

    /**
     * The key that moves the Tetris piece down.
     */
    private int myDownKey;

    /**
     * The key that drops the Tetris piece to the bottom of the board.
     */
    private int myDropKey;

    /**
     * The key that rotates the Tetris piece clockwise.
     */
    private int myCWKey;

    /**
     * The key that rotates the Tetris piece counter-clockwise.
     */
    private int myCCWKey;

    /**
     * The constructor for this class.
     * 
     * @param theTetrisGUI The Tetris GUI.
     * @param theControlScreen The JPanel that displays the controls.
     * @param theScreen The JPanel that displays the game board.
     * @param thePieceScreen The JPanel that displays the next piece.
     */
    public TetrisMenuBar(final TetrisGUI theTetrisGUI, final ControlScreen theControlScreen,
                         final Screen theScreen, final NextPieceScreen thePieceScreen) {
        super();
        myTetrisGUI = theTetrisGUI;
        myControlScreen = theControlScreen;
        myScreen = theScreen;
        myPieceScreen = thePieceScreen;
        defaultKeySetup();
        createFileMenu();
        createOptionsMenu();
        createHelpMenu();
    }

    /**
     * This method sets up the default keys.
     */
    private void defaultKeySetup() {
        myLeftKey = KeyEvent.VK_LEFT;
        myRightKey = KeyEvent.VK_RIGHT;
        myDownKey = KeyEvent.VK_DOWN;
        myDropKey = KeyEvent.VK_SPACE;
        myCWKey = KeyEvent.VK_X;
        myCCWKey = KeyEvent.VK_Z;
        myTetrisGUI.setKeys(myLeftKey, myRightKey, myDownKey, 
                            myDropKey, myCWKey, myCCWKey);
    }

    /**
     * Creates the file menu.
     */
    private void createFileMenu() {        
        final JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        add(fileMenu);

        final JMenuItem endGame = new JMenuItem("End Game", KeyEvent.VK_E);
        endGame.setEnabled(false);   
        endGame.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myTetrisGUI.endGame();
            }
        });

        final JMenuItem newGame = new JMenuItem("New Game", KeyEvent.VK_N);
        newGame.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myTetrisGUI.newGame();
            }
        });

        myTetrisGUI.addPropertyChangeListener(new PropertyChangeListener() {

            @Override
            public void propertyChange(final PropertyChangeEvent theEvent) {
                if ("PLAYING".equals(theEvent.getPropertyName())) {
                    if ((boolean) theEvent.getNewValue()) {
                        newGame.setEnabled(true);  
                        endGame.setEnabled(false);                
                    } else {
                        newGame.setEnabled(false);    
                        endGame.setEnabled(true);     
                    }
                }
            }
        });

        final JMenuItem quitMenu = new JMenuItem("Exit", KeyEvent.VK_X);
        quitMenu.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myTetrisGUI.endGame();
                myTetrisGUI.dispose();
            }
        });

        fileMenu.add(newGame);
        fileMenu.addSeparator();
        fileMenu.add(endGame);
        fileMenu.addSeparator();
        fileMenu.add(quitMenu);
    }

    /**
     * Creates the options menu.
     */
    private void createOptionsMenu() {
        final JMenu optionsMenu = new JMenu("Options");
        optionsMenu.setMnemonic(KeyEvent.VK_O);
        add(optionsMenu);

        final JMenu changeKeys = new JMenu("Change Keys");
        changeKeys.setMnemonic(KeyEvent.VK_C);

        final JMenuItem changeLeftKey = new JMenuItem("Change Left Key");
        final JMenuItem changeRightKey = new JMenuItem("Change Right Key");
        final JMenuItem changeDownKey = new JMenuItem("Change Down Key");
        final JMenuItem changeDropKey = new JMenuItem("Change Drop Key");
        final JMenuItem changeCWKey = new JMenuItem("Change Clockwise Key");
        final JMenuItem changeCCWKey = new JMenuItem("Change Counter-Clockwise Key");

        addListeners(changeLeftKey, changeRightKey, changeDownKey, changeDropKey, changeCWKey,
                     changeCCWKey);

        changeKeys.add(changeLeftKey);
        changeKeys.addSeparator();
        changeKeys.add(changeRightKey);
        changeKeys.addSeparator();
        changeKeys.add(changeDownKey);
        changeKeys.addSeparator();
        changeKeys.add(changeDropKey);
        changeKeys.addSeparator();
        changeKeys.add(changeCWKey);
        changeKeys.addSeparator();
        changeKeys.add(changeCCWKey);

        final JMenu changeVisual = new JMenu("Change Visuals");
        changeKeys.setMnemonic(KeyEvent.VK_V);

        final JCheckBoxMenuItem colorCheck = new JCheckBoxMenuItem("Add Colors");
        colorCheck.setMnemonic(KeyEvent.VK_C);
        colorCheck.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myScreen.toggleColors();
                myPieceScreen.toggleColors();
            }
        });
        changeVisual.add(colorCheck);
        changeVisual.addSeparator();

        final JCheckBoxMenuItem gridCheck = new JCheckBoxMenuItem("Add Grid");
        gridCheck.setMnemonic(KeyEvent.VK_G);
        gridCheck.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myScreen.toggleGrid();
            }
        });
        changeVisual.add(gridCheck);

        optionsMenu.add(changeKeys);
        optionsMenu.addSeparator();
        optionsMenu.add(changeVisual);
    }


    /**
     * Creates the help menu.
     */
    private void createHelpMenu() {
        final JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        add(helpMenu);

        final JMenuItem info = new JMenuItem("Scoring", KeyEvent.VK_A);
        info.addActionListener(new ActionListener() {
            private static final String SCORING = "4 points for each block set\n"
                            + "\n(40 * Level Number) for 1 line cleared"
                            + "\n(100 * Level Number) for 2 lines cleared"
                            + "\n(300 * Level Number) for 3 lines cleared"
                            + "\n(1200 * Level Number) for a Tetris";

            public void actionPerformed(final ActionEvent theEvent) {
                JOptionPane.showMessageDialog(myTetrisGUI, SCORING, info.getText(),
                                              JOptionPane.INFORMATION_MESSAGE);
            }
        });

        final JMenuItem about = new JMenuItem("About...", KeyEvent.VK_A);
        about.addActionListener(new ActionListener() {
            private static final String INFO = "TCSS 305 Tetris\nWinter 2016\nPeter Park"
                            + "\n\nAll Sounds were provided by Gaming Sound FX"
                            + "\nMusic by Smooth McGroove";

            public void actionPerformed(final ActionEvent theEvent) {
                JOptionPane.showMessageDialog(myTetrisGUI, INFO, about.getText(),
                                              JOptionPane.INFORMATION_MESSAGE);
            }
        });
        helpMenu.add(info);
        helpMenu.addSeparator();
        helpMenu.add(about);
    }

    /**
     * Set the keys in the control screen and the GUI.
     */
    private void setKeys() {
        myControlScreen.setKeys(myLeftKey, myRightKey, myDownKey, 
                                myDropKey, myCWKey, myCCWKey);
        myTetrisGUI.setKeys(myLeftKey, myRightKey, myDownKey, 
                            myDropKey, myCWKey, myCCWKey);
    }

    /**
     * This method adds ActionListeners to the JMenuItems passed in.
     * 
     * @param theLeftKey the JMenuItem that changes the key that moves the Tetris piece left.
     * @param theRightKey the JMenuItem that changes the key that moves the Tetris piece right.
     * @param theDownKey the JMenuItem that changes the key that moves the Tetris piece down.
     * @param theDropKey the JMenuItem that changes the key that drops the Tetris piece down.
     * @param theCWKey the JMenuItem that changes the key that rotates the Tetris piece right.
     * @param theCCWKey the JMenuItem that changes the key that rotates the Tetris piece left.
     */
    private void addListeners(final JMenuItem theLeftKey, final JMenuItem theRightKey, 
                              final JMenuItem theDownKey, final JMenuItem theDropKey, 
                              final JMenuItem theCWKey, final JMenuItem theCCWKey) {
        final String dialog = "Please input a new key:";

        theLeftKey.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                final String inputKey = JOptionPane.showInputDialog(dialog);
                if (inputKey != null && inputKey.length() != 0 
                                && checkKeys(KeyEvent.getExtendedKeyCodeForChar
                                             (inputKey.charAt(0)))) {
                    myLeftKey = KeyEvent.getExtendedKeyCodeForChar(inputKey.charAt(0));
                    setKeys();
                }
            }
        });

        theRightKey.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                final String inputKey = JOptionPane.showInputDialog(dialog);
                if (inputKey != null && inputKey.length() != 0 
                                && checkKeys(KeyEvent.getExtendedKeyCodeForChar
                                             (inputKey.charAt(0)))) {
                        myRightKey = KeyEvent.getExtendedKeyCodeForChar(inputKey.charAt(0));
                        setKeys();
                    }
            }
        });       

        theDownKey.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                final String inputKey = JOptionPane.showInputDialog(dialog);
                if (inputKey != null && inputKey.length() != 0 
                                && checkKeys(KeyEvent.getExtendedKeyCodeForChar
                                             (inputKey.charAt(0)))) {
                        myDownKey = KeyEvent.getExtendedKeyCodeForChar(inputKey.charAt(0));
                        setKeys();
                    }
            }
        });

        theDropKey.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                final String inputKey = JOptionPane.showInputDialog(dialog);
                if (inputKey != null && inputKey.length() != 0 
                                && checkKeys(KeyEvent.getExtendedKeyCodeForChar
                                             (inputKey.charAt(0)))) {
                        myDropKey = KeyEvent.getExtendedKeyCodeForChar(inputKey.charAt(0));
                        setKeys();
                    }
            }
        });    

        theCWKey.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                final String inputKey = JOptionPane.showInputDialog(dialog);
                if (inputKey != null && inputKey.length() != 0 
                                && checkKeys(KeyEvent.getExtendedKeyCodeForChar
                                             (inputKey.charAt(0)))) {
                        myCWKey = KeyEvent.getExtendedKeyCodeForChar(inputKey.charAt(0));
                        setKeys();
                    }
            }
        });

        theCCWKey.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                final String inputKey = JOptionPane.showInputDialog(dialog);
                if (inputKey != null && inputKey.length() != 0 
                                && checkKeys(KeyEvent.getExtendedKeyCodeForChar
                                             (inputKey.charAt(0)))) {
                        myCCWKey = KeyEvent.getExtendedKeyCodeForChar(inputKey.charAt(0));
                        setKeys();
                    }
            }
        });    
    }

    /**
     * This method checks if the key passed in is already being used.
     * 
     * @param theKey The key to check.
     * @return Returns whether the key is being used.
     */
    private boolean checkKeys(final int theKey) {
        return !(myLeftKey == theKey || myRightKey == theKey || myDownKey == theKey 
                        || myDropKey == theKey || myCWKey == theKey || myCCWKey == theKey);
    }
}
