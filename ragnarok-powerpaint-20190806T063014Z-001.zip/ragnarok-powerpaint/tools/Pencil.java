/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.Shape;
import java.awt.geom.GeneralPath;

/**
 * This class creates a pencil tool.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class Pencil extends AbstractTool {
    
    /**
     * The path of the pencil tool.
     */
    private GeneralPath myPath;

    /**
     * Starts to draw the path at the initial x and y coordinates.
     *
     * @return myPath the start of the path.
     */
    public Shape start() {
        myPath = new GeneralPath(); 
        myPath.moveTo(myInitialX, myInitialY);
        return myPath;
    }

    /**
     * Draws the path from the initial x and y coordinates to the new ones passed.
     * 
     * @return myPath the extended path.
     */
    public Shape move() {
        myPath.lineTo(myEndX, myEndY);
        return myPath;
    }
}