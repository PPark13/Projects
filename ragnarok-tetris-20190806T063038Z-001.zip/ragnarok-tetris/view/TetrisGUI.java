/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import model.Block;
import model.Board;
import model.TetrisPiece;
import sound.SoundPlayer;

/**
 * This class sets up the frames and handles the information sent from the Board.
 * 
 * @author Peter Park
 * @version 4.0
 */
public class TetrisGUI extends JFrame implements Observer {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = -2654839630869568087L;
    
    /**
     * The name of the property that is being fired.
     */
    private static final String IS_PLAYING = "PLAYING";

    /**
     * The delay for the timer (Set for 1.1 second).
     */
    private static final int TIMER_DELAY = 1100;

    /**
     * The amount of points for one piece being frozen.
     */
    private static final int ONE_PIECE = 4;

    /**
     * The amount of points for one line being cleared.
     */
    private static final int ONE_LINE = 40;

    /**
     * The amount of points for two lines being cleared.
     */
    private static final int TWO_LINES = 100;

    /**
     * The amount of points for three lines being cleared.
     */
    private static final int THREE_LINES = 300;

    /**
     * The amount of points for four lines being cleared.
     */
    private static final int FOUR_LINES = 1200;
    
    /**
     * The highest level on Tetris the user can reach.
     */
    private static final int MAX_LEVELS = 10;

    /**
     * The timer that animates the game.
     */
    private final Timer myTimer;

    /**
     * The board that handles the back end code.
     */
    private final Board myBoard;

    /**
     * The screen that displays the Tetris pieces.
     */
    private final Screen myScreen;

    /**
     * The screen that displays the next Tetris piece.
     */
    private final NextPieceScreen myPieceScreen;

    /**
     * The positions of the blocks on the board.
     */
    private List<Block[]> myBoardData;

    /**
     * The boolean check to see if the game has ended.
     */
    private boolean myGameOver;

    /**
     * The boolean check to see if the game is paused.
     */
    private boolean myGamePaused;

    /**
     * The screen that displays the controls.
     */
    private final ControlScreen myControlScreen;

    /**
     * The screen that displays the points.
     */
    private final PointScreen myPointScreen;

    /**
     * The key that moves the Tetris piece left.
     */
    private int myLeftKey;

    /**
     * The key that moves the Tetris piece right.
     */
    private int myRightKey;

    /**
     * The key that moves the Tetris piece down.
     */
    private int myDownKey;

    /**
     * The key that drops the Tetris piece to the bottom of the board.
     */
    private int myDropKey;

    /**
     * The key that rotates the Tetris piece clockwise.
     */
    private int myCWKey;

    /**
     * The key that rotates the Tetris piece counter-clockwise.
     */
    private int myCCWKey;

    /**
     * The total score of the user.
     */
    private int myScore;

    /**
     * The amount of lines the user has cleared.
     */
    private int myLines;

    /**
     * The current level that the user is on.
     */
    private int myLevel;
    
    /**
     * The file path for the Tetris theme.
     */
    private String myTetrisTheme;
    
    /**
     * The sound player for the GUI.
     */
    private final SoundPlayer mySoundPlayer;
    
    /**
     * The constructor for this class.
     */
    public TetrisGUI() {
        super("Tetris");

        myTimer = new Timer(TIMER_DELAY, null);
        myBoard = new Board();
        myBoardData = new ArrayList<Block[]>();
        myScreen = new Screen();  
        myPieceScreen = new NextPieceScreen();
        myControlScreen = new ControlScreen();
        myPointScreen = new PointScreen();
        mySoundPlayer = new SoundPlayer();
        
        setup();
    }

    /**
     * This method sets up all of the components.
     */
    private void setup() {       
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);     

        final JPanel westPanel = new JPanel();
        westPanel.add(myScreen);
        add(westPanel, BorderLayout.WEST);
        final JPanel gridPanel = new JPanel();

        gridPanel.setLayout(new GridLayout(ONE_PIECE - 1, 1));
        gridPanel.add(myPieceScreen);
        gridPanel.add(myControlScreen);
        gridPanel.add(myPointScreen);

        add(gridPanel, BorderLayout.EAST);

        setJMenuBar(new TetrisMenuBar(this, myControlScreen, myScreen, myPieceScreen));
        this.addKeyListener(new TetrisKeyListener());

        setResizable(false);
        pack();
        setVisible(true);  
        myBoard.addObserver(this);

        myTimer.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myBoard.step();
            }
        }); 
        
        myTetrisTheme = "sounds/Tetris-Theme.wav";
    }

    /**
     * This method starts the game.
     */
    public void start() {
        myBoard.newGame();
        myScore = 0;
        myLines = 0;
        myLevel = 1;
        setLevelSpeed();
        myGameOver = false;
        myGamePaused = false;
    }
    
    /**
     * This method sets up a new game.
     */
    public void newGame() {
        start();
        myTimer.restart();
        firePropertyChange(IS_PLAYING, !myGameOver, myGameOver);
        mySoundPlayer.stopAll();
        playTheme();
    }

    /**
     * Sets the default keys to control the Tetris piece.
     * 
     * @param theLeft The key to move the piece left.
     * @param theRight The key to move the piece right.
     * @param theDown The key to move the piece down.
     * @param theDrop The key to drop the piece to the bottom.
     * @param theCW The key to rotate the piece clockwise.
     * @param theCCW The key to rotate the piece counter-clockwise.
     */
    public void setKeys(final int theLeft, final int theRight, final int theDown, 
                        final int theDrop, final int theCW, final int theCCW) {
        myLeftKey = theLeft;
        myRightKey = theRight;
        myDownKey = theDown;
        myDropKey = theDrop;
        myCWKey = theCW;
        myCCWKey = theCCW;
    }
    
    /**
     * This method sets the speed of the timer/game.
     */
    private void setLevelSpeed() {
        myTimer.setDelay(TIMER_DELAY - (myLevel * TWO_LINES));
    }
    
    /**
     * This method ends the current game.
     */
    public void endGame() {
        firePropertyChange(IS_PLAYING, myGameOver, !myGameOver);
        myGameOver = true;
        myTimer.stop();
        mySoundPlayer.stopAll();
        mySoundPlayer.play("sounds/Losing_horn.wav");
        JOptionPane.showMessageDialog(this, "Game Over");
    }
    
    /**
     * This method starts/stops the timer/game.
     */
    private void pause() {
        if (myGamePaused) {
            myTimer.start();
            myGamePaused ^= true;
            playTheme();
        } else {            
            myTimer.stop();
            myGamePaused ^= true;
            mySoundPlayer.play("sounds/Pause.wav");
            mySoundPlayer.pause(myTetrisTheme);
        }
    }
    
    /**
     * This method plays the Tetris theme.
     */
    private void playTheme() {
        mySoundPlayer.loop(myTetrisTheme);
    }
    
    /**
     * This method plays a sound when a line is cleared.
     */
    private void playLine() {
        mySoundPlayer.play("sounds/Punch.wav");
    }
    
    /**
     * This method plays a sound when the piece moves.
     */
    private void playMovement() {
        mySoundPlayer.play("sounds/Hitmarker.wav");
    }

    /**
     * This method updates the information of the GUI sent from the board.
     */
    @Override
    public void update(final Observable theObservable, final Object theData) {        
        if (theData instanceof List) {
            myBoardData = (List<Block[]>) theData;
            myScreen.updateBlocks(myBoardData);
        } else if (theData instanceof TetrisPiece) {
            NextPieceScreen.setPiece((TetrisPiece) theData);
            myScore += ONE_PIECE;
        } else if (theData instanceof Integer[]) {
            final Integer[] lines = (Integer[]) theData;
            if (lines.length == 1) {
                myScore += ONE_LINE * myLevel;
                playLine();
            } else if (lines.length == 2) {
                myScore += TWO_LINES * myLevel;
                playLine();
            } else if (lines.length == ONE_PIECE - 1) {
                myScore += THREE_LINES * myLevel;
                playLine();
            } else {
                myScore += FOUR_LINES * myLevel;
                mySoundPlayer.play("sounds/applause.wav");
                mySoundPlayer.play("sounds/Wow.wav");
            }
            myLines += lines.length;    

            if (myLevel != MAX_LEVELS) {
                myLevel = (myLines / (MAX_LEVELS / 2)) + 1;
            }         
            setLevelSpeed();
        } else if (theData instanceof Boolean && (boolean) theData) {
            endGame();
        }
        repaint();
        myPointScreen.setPoints(myScore, myLines, myLevel);
    }

    /**
     * This class determines what happens when keys are pressed.
     * 
     * @author Peter Park
     * @version 2
     */
    private class TetrisKeyListener extends KeyAdapter { 

        /**
         * @param theEvent The key that was pressed.
         */
        public void keyPressed(final KeyEvent theEvent) {
            if (myTimer.isRunning()) {
                if (theEvent.getKeyCode() == myDropKey) {
                    myBoard.drop();
                    playMovement();
                } else if (theEvent.getKeyCode() == myLeftKey) {
                    myBoard.left();
                    playMovement();
                } else if (theEvent.getKeyCode() == myRightKey) {
                    myBoard.right();
                    playMovement();
                } else if (theEvent.getKeyCode() == myDownKey) {
                    myBoard.down();
                    playMovement();
                } else if (theEvent.getKeyCode() == myCCWKey) {
                    myBoard.rotateCCW();
                    playMovement();
                } else if (theEvent.getKeyCode() == myCWKey) {
                    myBoard.rotateCW();
                    playMovement();
                }
            }
            if (theEvent.getKeyCode() == KeyEvent.VK_P) {
                pause();
            }            
        }
    }
}
