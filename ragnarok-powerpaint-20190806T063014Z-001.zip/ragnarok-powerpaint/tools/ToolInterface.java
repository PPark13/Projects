/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.Shape;

/**
 * This is the interface for the tool objects.
 * 
 * @author Peter Park
 * @version 8.1
 *
 */
public interface ToolInterface {
    
    /**
     * Sets the initial x and y coordinates.
     * 
     * @param theX the initial x coordinate.
     * @param theY the initial y coordinate.
     */
    void setStartPoint(final int theX, final int theY);
    
    /**
     * Sets the end/final x and y coordinates.
     * 
     * @param theX the end x coordinate.
     * @param theY the end y coordinate.
     */
    void setEndPoint(final int theX, final int theY);
    
    /**
     * Starts drawing the shape at the start point.
     * 
     * @return myShape the initial shape.
     */
    Shape start();

    /**
     * Moves the drawing from the start point to the end point.
     * 
     * @return myShape the shape that was drawn.
     */
    Shape move();

    /**
     * Provides the name of the tool.
     * 
     * @return myName the name of the tool.
     */
    String getName();
    
    /**
     * Checks to see if the square/circle button is toggled on.
     * 
     * @param theSquareCircle the boolean state of the square/circle button.
     */
    void setSquareCircle(final boolean theSquareCircle);
}
