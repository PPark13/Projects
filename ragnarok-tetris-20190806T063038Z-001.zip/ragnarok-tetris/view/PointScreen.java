/*
 * TCSS 305 - Winter 2016
 * Assignment 6 - Tetris
 */

package view;

import javax.swing.JTextPane;

/**
 * This class displays the controls for the game.
 * 
 * @author Peter Park
 * @version 4.0
 */
public class PointScreen extends JTextPane {
            
    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 8227486928342102999L;

    /**
     * This is the max level to check for.
     */
    private static final int LEVEL_CHECK = 10;

    /**
     * This string contains all of the point information.
     */
    private String myPoints;
    
    /**
     * The user's score.
     */
    private int myScore;
    
    /**
     * The amount of lines the user has cleared.
     */
    private int myLines;
    
    /**
     * The level that the user is on.
     */
    private int myLevel;
    
    /**
     * The amount of lines required to reach the next level.
     */
    private int myNextLevel;
    
    /**
     * This is the default constructor for this class.
     */
    public PointScreen() {
        super();
        
        myScore = 0;
        myLines = 0;
        myLevel = 1;
        
        setFocusable(false);
        setupText();
        setText(myPoints);
    }
    
    /**
     * This method sets the information for the score, the amount of lines, and the level.
     * 
     * @param theScore the number to set the score.
     * @param theLines the number to set the lines cleared.
     * @param theLevel the number to set the level.
     */
    public void setPoints(final int theScore, final int theLines, final int theLevel) {
        myScore = theScore;
        myLines = theLines;
        myLevel = theLevel;
        myNextLevel = (LEVEL_CHECK / 2) - (myLines % (LEVEL_CHECK / 2));
        setupText();
        setText(myPoints);
    }
    
    /**
     * This method writes the text that displays the points.
     */
    private void setupText() {          
        myPoints = "";
        myPoints += "                   Points\n";
        myPoints += "\nScore: " + myScore;
        myPoints += "\nLines: " + myLines;
        myPoints += "\nLevel: " + myLevel;
        if (myLevel == LEVEL_CHECK) {
            myPoints += "\nLines to next Level: Max Level";
        } else {
            myPoints += "\nLines to next Level: " + myNextLevel;
        }
    }
}
