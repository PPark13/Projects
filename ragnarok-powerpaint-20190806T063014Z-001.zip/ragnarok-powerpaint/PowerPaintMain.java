/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

import gui.PowerPaintGUI;

import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Runs PowerPaint by instantiating and starting the PowerPaintGUI.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class PowerPaintMain extends JFrame {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 2061432889050809407L;

    /**
     * The main method of PowerPaintMain. Sets the look and feel and starts the GUI.
     * 
     * @param theArgs Comment line argument (ignored).
     */
    public static void main(final String... theArgs) {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        } catch (final UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        } catch (final IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (final InstantiationException ex) {
            ex.printStackTrace();
        } catch (final ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        
        UIManager.put("swing.boldMetal", Boolean.FALSE);

        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PowerPaintGUI().start();
            }
        });
    }
}