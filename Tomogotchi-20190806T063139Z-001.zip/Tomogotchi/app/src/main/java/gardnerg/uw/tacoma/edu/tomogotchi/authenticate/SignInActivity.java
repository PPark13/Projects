package gardnerg.uw.tacoma.edu.tomogotchi.authenticate;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import gardnerg.uw.tacoma.edu.tomogotchi.Account;
import gardnerg.uw.tacoma.edu.tomogotchi.LoginFragment;
import gardnerg.uw.tacoma.edu.tomogotchi.MainScreen;
import gardnerg.uw.tacoma.edu.tomogotchi.PetSelectActivity;
import gardnerg.uw.tacoma.edu.tomogotchi.R;

public class SignInActivity extends AppCompatActivity
        implements LoginFragment.LoginInteractionListener, LoginFragment.OnRegisterListener {

    private String ADD_USER_URL = "http://cssgate.insttech.washington.edu/~_450bteam11/AddUser.php";

    /**
     * called on create of the activity fills this activity with the loginfragment
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, new LoginFragment())
                .commit();

    }

    /**
     * allows the user to log in, does nto have
     * @param userId
     * @param pwd
     */
    @Override
    public void login(String userId, String pwd) {
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            //Check if the login and password are valid
            //new LoginTask().execute(url);
        }
        else {
            Toast.makeText(this, "No network connection available. Cannot authenticate user",
                    Toast.LENGTH_SHORT) .show();
            return;
        }
//Store in file

        if (networkInfo != null && networkInfo.isConnected()) {
            //Check if the login and password are valid
            //new LoginTask().execute(url);
            try {
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(
                        openFileOutput(getString(R.string.LOGIN_FILE)
                                , Context.MODE_PRIVATE));
                outputStreamWriter.write("email = " + userId + ";");
                outputStreamWriter.write("password = " + pwd);
                outputStreamWriter.close();
                Toast.makeText(this,"Stored in File Successfully!", Toast.LENGTH_LONG)
                        .show();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
//        if (user has pet) {
//            Intent i = new Intent(this, MainScreen.class);
//            startActivity(i);
//            finish();
//        } else {
            Intent i = new Intent(this, PetSelectActivity.class);
            startActivity(i);
            finish();
//        }
    }

    /**
     * registers an account and tcalls the url builder to save the information
     * @param account
     */
    @Override
    public void register(Account account) {
        RegisterAsyncTask myTask = new RegisterAsyncTask();
//        System.out.println("HERE!");
        myTask.execute(new String[]{buildUserURL(account)});
//        System.out.println("HERE2!");
    }

    /**
     * builds the URL for adding an account
     * @param account
     * @return
     */
    private String buildUserURL(Account account) {
        Context context = getApplicationContext();
        StringBuilder sb = new StringBuilder(ADD_USER_URL);

        try {

            String myEmail = account.getMyEmail();
            sb.append("?id=");
            sb.append(myEmail);


            String myPassword = account.getMyPass();
            sb.append("&password=");
            sb.append(URLEncoder.encode(myPassword, "UTF-8"));

            Log.i("SignInActivity", sb.toString());

        }
        catch(Exception e) {
            Toast.makeText(context, "Something wrong with the url" + e.getMessage(), Toast.LENGTH_LONG)
                    .show();
        }
        return sb.toString();
    }

    /**
     * Async task to run thread in background to register.
     */
    private class RegisterAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            String response = "";
            HttpURLConnection urlConnection = null;
            for (String url : urls) {
                try {
                    URL urlObject = new URL(url);
                    urlConnection = (HttpURLConnection) urlObject.openConnection();

                    InputStream content = urlConnection.getInputStream();

                    BufferedReader buffer = new BufferedReader(new InputStreamReader(content));
                    String s = "";
                    while ((s = buffer.readLine()) != null) {
                        response += s;
                    }

                } catch (Exception e) {
                    response = "Unable to add user, Reason: "
                            + e.getMessage();
                } finally {
                    if (urlConnection != null)
                        urlConnection.disconnect();
                }
            }
            return response;
        }

        /**
         * executes after thread is done
         * @param result
         */
        @Override
        protected void onPostExecute(String result) {
            try {
                JSONObject jsonObject = new JSONObject(result);
                String status = (String) jsonObject.get("result");
                if (status.equals("success")) {
                    Toast.makeText(getApplicationContext()
                            , "User successfully registered!"
                            , Toast.LENGTH_LONG)
                            .show();

                } else {
                    Toast.makeText(getApplicationContext(), "Failed to register: "
                                    + jsonObject.get("error")
                            , Toast.LENGTH_LONG)
                            .show();
                }
            } catch (JSONException e) {
                Toast.makeText(getApplicationContext(), "Something wrong with the data" +
                        e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }


    }
}
