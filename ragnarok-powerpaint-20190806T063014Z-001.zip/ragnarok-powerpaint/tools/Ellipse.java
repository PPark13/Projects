/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.geom.Ellipse2D;

/**
 * This class creates an ellipse tool.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class Ellipse extends AbstractRectangle {
    
    /**
     * Constructor for the Ellipse class.
     */
    public Ellipse() {
        super(new Ellipse2D.Double());
    }
}
