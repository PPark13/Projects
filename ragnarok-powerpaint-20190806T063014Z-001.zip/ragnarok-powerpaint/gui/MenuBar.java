/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import listeners.ColorAction;
import listeners.ToolAction;

/**
 * The menu bar that will be used in the PowerPaint Java application.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class MenuBar extends JMenuBar {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 2640910736190261425L;

    /**
     * The default thickness to draw with.
     */
    private static final int DEFAULT_LINE_THICKNESS = 5;

    /**
     * A collection of tools.
     */
    private final List<ToolAction> myToolActions;

    /**
     * The canvas to draw on.
     */
    private final Canvas myCanvas;

    /**
     * The Color action to add to the menu.
     */
    private final ColorAction myChangeColor;

    /**
     * The frame of the Java application.
     */
    private final JFrame myFrame;

    /**
     * The constructor for the menu bar.
     * 
     * @param theToolActions the collection of tool actions.
     * @param theCanvas the canvas to draw with.
     * @param theFrame the frame for the application.
     */
    public MenuBar(final List<ToolAction> theToolActions, 
                   final Canvas theCanvas, final JFrame theFrame) {
        super();
        myToolActions = theToolActions;
        myCanvas = theCanvas;
        myChangeColor = new ColorAction(myCanvas);
        myFrame = theFrame;

        createFileMenu();
        createOptionsMenu();
        createToolsMenu();
        createHelpMenu();
    }

    /**
     * Creates the file menu.
     */
    private void createFileMenu() {        
        final JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F);
        add(fileMenu);

        final JMenuItem clearMenu = new JMenuItem("Undo all changes", KeyEvent.VK_U);
        clearMenu.setEnabled(false);
        myCanvas.addPropertyChangeListener(new PropertyChangeListener() {

            @Override
            public void propertyChange(final PropertyChangeEvent theEvent) {
                if ("ART".equals(theEvent.getPropertyName()) 
                                && (boolean) theEvent.getNewValue()) {
                    clearMenu.setEnabled(true);                
                }
            }
        });
        
        clearMenu.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myCanvas.clearDrawings();
                clearMenu.setEnabled(false);
            }
        });

        fileMenu.add(clearMenu);

        fileMenu.addSeparator();
        final JMenuItem quitMenu = new JMenuItem("Exit", KeyEvent.VK_X);
        quitMenu.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                myFrame.dispose();
            }
        });
        fileMenu.add(quitMenu);
    }

    /**
     * Creates the options menu.
     */
    private void createOptionsMenu() {
        final JMenu optionsMenu = new JMenu("Options");
        optionsMenu.setMnemonic(KeyEvent.VK_O);
        add(optionsMenu);

        final JCheckBoxMenuItem squareCircleMenu = new JCheckBoxMenuItem("Square/Circle only");
        squareCircleMenu.setMnemonic(KeyEvent.VK_S);
        squareCircleMenu.addActionListener(new ActionListener() {
            public void actionPerformed(final ActionEvent theEvent) {
                for (final ToolAction tool : myToolActions) {
                    tool.setSquareCircle(squareCircleMenu.isSelected());
                }            
            }
        });
        optionsMenu.add(squareCircleMenu);

        optionsMenu.addSeparator();

        final JMenu thicknessMenu = new JMenu("Thickness");
        thicknessMenu.setMnemonic(KeyEvent.VK_T);
        optionsMenu.add(thicknessMenu);

        final JSlider thicknessSlider = new JSlider(0, 20, 5);
        thicknessSlider.setMajorTickSpacing(DEFAULT_LINE_THICKNESS);
        thicknessSlider.setMinorTickSpacing(1);
        thicknessSlider.setPaintTicks(true);
        thicknessSlider.setPaintLabels(true);

        thicknessSlider.addChangeListener(new ChangeListener() {

            @Override
            public void stateChanged(final ChangeEvent theEvent) {
                myCanvas.setThickness(thicknessSlider.getValue());                   
            }        
        });


        thicknessMenu.add(thicknessSlider);

        optionsMenu.addSeparator();

        optionsMenu.add(myChangeColor);
    }

    /**
     * Creates the tools menu.
     */
    private void createToolsMenu() {
        final JMenu toolsMenu = new JMenu("Tools");
        toolsMenu.setMnemonic(KeyEvent.VK_T);
        add(toolsMenu);

        final ButtonGroup menuToolGroup = new ButtonGroup();
        JRadioButtonMenuItem radioButton;

        for (final ToolAction tool : myToolActions) {
            radioButton = new JRadioButtonMenuItem(tool);
            toolsMenu.add(radioButton);
            menuToolGroup.add(radioButton);
        }
    }

    /**
     * Creates the help menu.
     */
    private void createHelpMenu() {
        final JMenu helpMenu = new JMenu("Help");
        helpMenu.setMnemonic(KeyEvent.VK_H);
        add(helpMenu);
        final ImageIcon image = new ImageIcon("images/uw.gif");

        final JMenuItem about = new JMenuItem("About...", KeyEvent.VK_A);
        about.addActionListener(new ActionListener() {
            private static final String INFO = "TCSS 305 PowerPaint\nWinter 2016\nPeter Park";

            public void actionPerformed(final ActionEvent theEvent) {
                JOptionPane.showMessageDialog(myCanvas, INFO, about.getText(),
                                              JOptionPane.INFORMATION_MESSAGE, image);
            }
        });
        helpMenu.add(about);
    }
}
