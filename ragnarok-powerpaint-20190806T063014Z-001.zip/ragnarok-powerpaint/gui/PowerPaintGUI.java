/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package gui;

import java.awt.BorderLayout;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import listeners.ToolAction;
import tools.Ellipse;
import tools.Line;
import tools.Pencil;
import tools.Rectangle;

/**
 * Creates the GUI for the PowerPaint Java application.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class PowerPaintGUI extends JFrame {

    /**
     * The generated serial version UID for this class.
     */
    private static final long serialVersionUID = 3165411042103419045L;

    /**
     * The class that is used to draw on.
     */
    private final Canvas myCanvas;

    /**
     * A collection of tool actions and tools.
     */
    private final List<ToolAction> myToolActions;

    /**
     * The constructor for GUI.
     */
    public PowerPaintGUI() {
        super("PowerPaint");
        myToolActions = new ArrayList<ToolAction>();
        myCanvas = new Canvas();
    }
    
    /**
     * Starts the construction of the GUI including the menu bar, tool bar, and canvas.
     */
    public void start() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        createActions();

        setJMenuBar(new MenuBar(myToolActions, myCanvas, this));
        
        add(new ToolBar(myToolActions), BorderLayout.SOUTH);
        add(myCanvas, BorderLayout.CENTER);
        
        try {
            setIconImage(ImageIO.read(new File("images/uw.gif")));
        } catch (final IOException exc) {
            exc.printStackTrace();
        }
        
        pack();
        setVisible(true);    
    }

    /**
     * Adds all of the actions and tools into a collection.
     */
    private void createActions() {
        myToolActions.add(new ToolAction(myCanvas, new Pencil()));
        myToolActions.add(new ToolAction(myCanvas, new Line()));
        myToolActions.add(new ToolAction(myCanvas, new Rectangle()));
        myToolActions.add(new ToolAction(myCanvas, new Ellipse()));
    }
}
