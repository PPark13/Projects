package gardnerg.uw.tacoma.edu.tomogotchi;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import gardnerg.uw.tacoma.edu.tomogotchi.authenticate.SignInActivity;


public class MainScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_signin,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.info:
                Intent intent = new Intent(this, ControlsActivity.class);
                startActivity(intent);
//                finish();
                return true;
            case R.id.action_logout:
                Intent i = new Intent(this, SignInActivity.class);
                startActivity(i);
//                finish();
                return true;
        }
        return true;
    }

}
