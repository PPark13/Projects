/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

import java.awt.geom.Rectangle2D;

/**
 * This class creates a rectangle tool.
 * 
 * @author Peter Park
 * @version 8.1
 */
public class Rectangle extends AbstractRectangle {
    
    /**
     * Constructor for the rectangle class.
     */
    public Rectangle() {
        super(new Rectangle2D.Double());
    }
}
