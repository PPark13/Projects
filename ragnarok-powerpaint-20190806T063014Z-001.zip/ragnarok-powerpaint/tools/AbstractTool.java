/*
 * TCSS 305 - Winter 2016
 * Assignment 5 - PowerPaint
 */

package tools;

/**
 * This class is an abstract tool which contains methods and fields that all tools should have.
 * 
 * @author Peter Park
 * @version 8.1
 */
public abstract class AbstractTool implements ToolInterface {
    
    /**
     * The initial x value.
     */
    protected int myInitialX;

    /**
     * The initial y value.
     */
    protected int myInitialY;
    
    /**
     * The final/end x value.
     */
    protected int myEndX;

    /**
     * The final/end y value.
     */
    protected int myEndY;
    
    /**
     * A check to see if the square/circle button is toggled on.
     */
    protected boolean mySquareCircle;

    /**
     * The name of the tool.
     */
    private final String myName;

    /**
     * Constructor for the AbstractTool class.
     */
    public AbstractTool() {
        myName = getClass().getSimpleName();
        mySquareCircle = false;
    }
    
    /**
     * Sets the initial x and y value.
     * 
     * @param theX the initial x value to set.
     * @param theY the initial y value to set.
     */
    public void setStartPoint(final int theX, final int theY) {
        myInitialX = theX;
        myInitialY = theY;
    }
    
    /**
     * Sets the ending x and y value.
     * 
     * @param theX the end x value to set.
     * @param theY the end y value to set.
     */
    public void setEndPoint(final int theX, final int theY) {
        myEndX = theX;
        myEndY = theY;
    }

    /**
     * Returns the name of the tool.
     * 
     * @return myName the name of the tool.
     */
    public final String getName() {
        return myName;
    }
    
    /**
     * Sets the square/circle checker to be the same as the parameter passed in.
     * 
     * @param theSquareCircle the boolean state of the square/circle button.
     */
    public void setSquareCircle(final boolean theSquareCircle) {
        mySquareCircle = theSquareCircle;
    }

}
